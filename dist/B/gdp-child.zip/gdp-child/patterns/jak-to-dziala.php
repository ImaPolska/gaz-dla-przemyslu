<?php
/**
 * Title: Jak to działa
 * Slug: gdp/jak-to-dziala
 * Categories: gdp
 * Block Types: core/group
 */
?>
<!-- wp:group {"metadata":{"name":"Sekcja produktu"},"templateLock":"contentOnly","className":"gdp-section gdp-product-content"} -->
<div class="wp-block-group gdp-section gdp-product-content"><!-- wp:heading --><h2 class="wp-block-heading">[[nagłówek sekcji]]</h2><!-- /wp:heading --><!-- wp:paragraph --><p>[[treść sekcji]]</p><!-- /wp:paragraph --></div><!-- /wp:group -->
